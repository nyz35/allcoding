package task;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.Year;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;

import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<MyKey,MyValue,IntWritable,IntWritable> {
	   static int count=0;
	   HashMap<String,Integer> hm=new HashMap<String, Integer>();
	   public void setup(Context context) throws IOException{
			 Path[] allFiles=DistributedCache.getLocalCacheFiles(context.getConfiguration());
			 
			 for(Path eachFile:allFiles){
				 BufferedReader br=new BufferedReader(new FileReader(eachFile.toString()));
				 
				 String line=null;
				 while((line=br.readLine())!=null){
					 String[] arr=line.split(",");
					 String minamt=arr[0].trim();
					 String maxamt=arr[1].trim();
					 Integer pension=Integer.parseInt(arr[2]);
					 hm.put(new String(minamt+","+maxamt), pension);
				 }	       
				 br.close();		
			 }

		     }
		     
	   
       public void map(MyKey key, MyValue value,Context context) throws IOException, InterruptedException{
    	       Configuration cfg=context.getConfiguration();
    	       int year=Integer.parseInt(cfg.get("year"));
    	   
    	        int diff=year- 2016;

    	        double income=key.getInc().get();
    	        
    	        Set<Entry<String,Integer>> set=hm.entrySet();
    	        
    	        Iterator<Entry<String, Integer>> it=set.iterator();
    	        int pension=0;
    	        
    	       if (value.getVal().get()+diff>=60){ 
    	        while(it.hasNext()){
    	        	String mykey=it.next().getKey();
    	        	String[] minmax=mykey.split(",");
    	        	String minrange=minmax[0];
    	        	String maxrange=minmax[1];
    	        	if(income>=Double.parseDouble(minrange) & income<=Double.parseDouble(maxrange)){
    	        	    pension=hm.get(mykey);
    	        	}
    	        }
    	        
    	        context.write(new IntWritable(1), new IntWritable(pension));;
    	        }
    	   
       }
}
