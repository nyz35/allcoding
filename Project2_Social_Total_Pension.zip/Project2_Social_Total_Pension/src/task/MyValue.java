package task;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Writable;

public class MyValue implements Writable {
    IntWritable val;
    
	public IntWritable getVal() {
		return val;
	}

	public void setVal(IntWritable val) {
		this.val = val;
	}

	@Override
	public void readFields(DataInput arg0) throws IOException {
		val.readFields(arg0);
		
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		val.write(arg0);
		
	}

}
